export default {
  testEnvironment: 'node',
  transform: {},
};
